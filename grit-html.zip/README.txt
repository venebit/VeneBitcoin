#Grit-html
HTML version of Grit
Designed by devfloat.net

#Support
https://devfloat.net/forums/

#License
Free for using on your website or client projects. 
Please don't sell this template on your website or marketplaces. It's free you know.

#WordPress
We also have a premium wordpress version. Get it if you want it. :)
https://devfloat.net/themes/grit/